# salih.ai

A lightweight browser-based translation app with Voice, Type, and Image OCR modes.

## Run locally

1. Install Python 3 if it is not already available.
2. Open a terminal in this folder and run:

   ```sh
   python3 -m http.server 8000
   ```

3. Open <http://127.0.0.1:8000> in Chrome or another supported browser.
4. Allow microphone access when prompted to use Voice mode.

The app has no build step or package installation. Translation, OCR, and some browser speech recognition features require an internet connection. OCR loads its engine on demand from a CDN. Speech recognition support depends on the browser.

## Files

- `index.html` — app structure and metadata
- `styles.css` — responsive dark glass interface
- `app.js` — translation, speech, OCR, and controls
