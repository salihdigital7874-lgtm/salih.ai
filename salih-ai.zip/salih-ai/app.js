const $ = (id) => document.getElementById(id);
const sourceLang = $('sourceLang');
const targetLang = $('targetLang');
const originalText = $('originalText');
const translationText = $('translationText');
const toast = $('toast');
const languageNames = { ml: 'Malayalam', en: 'English', ta: 'Tamil', hi: 'Hindi', ar: 'Arabic', manglish: 'Manglish' };
const flags = { ml: '🇮🇳', en: '🇬🇧', ta: '🇮🇳', hi: '🇮🇳', ar: '🇦🇪', manglish: '🔤' };
let mode = 'voice', recognition = null, listening = false, translating = false, translateTimer, toastTimer, currentImage = null, tesseractPromise = null;

function sayToast(message) { toast.textContent = message; toast.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 2500); }
function getInput() { return originalText.value.trim(); }
function updateCounts() { const text = originalText.value; const words = text.trim() ? text.trim().split(/\s+/).length : 0; const counter = $('sourceCounts'); if (counter) counter.textContent = `${words} ${words === 1 ? 'word' : 'words'} · ${text.length} characters`; }
function setInput(text, translate = true) {
  originalText.value = text; updateCounts();
  const typeValue = $('sourceText');
  if (typeValue.value !== text) typeValue.value = text;
  $('charCount').textContent = `${text.length.toLocaleString()} / 5,000`;
  if (translate) queueTranslation();
}
function showTranslation(text, target = targetLang.value) {
  const clean = (text || '').trim();
  const placeholder = document.querySelector('.translation-placeholder');
  if (!clean) { translationText.classList.add('hidden'); placeholder.classList.remove('hidden'); translationText.textContent = ''; return; }
  placeholder.classList.add('hidden'); translationText.classList.remove('hidden'); translationText.textContent = clean;
  translationText.dir = target === 'ar' ? 'rtl' : 'auto';
}
function labelTarget() { $('targetLabel').textContent = `${flags[targetLang.value]}  ${languageNames[targetLang.value]}`; }
function setMode(next) {
  mode = next;
  document.querySelectorAll('.mode-tab').forEach((tab) => { const active = tab.dataset.mode === next; tab.classList.toggle('active', active); tab.setAttribute('aria-selected', String(active)); });
  document.querySelectorAll('.mode-view').forEach((view) => view.classList.toggle('active', view.id === `${next}View`));
  const widths = { voice: ['37px', '61px'], type: ['117px', '51px'], image: ['199px', '57px'] };
  document.querySelector('.tab-indicator').style.left = widths[next][0];
  document.querySelector('.tab-indicator').style.width = widths[next][1];
  $('inputKicker').textContent = { voice: 'SPEAK TO TRANSLATE', type: 'WRITE TO TRANSLATE', image: 'SCAN AN IMAGE' }[next];
  if (next !== 'voice' && listening) stopListening();
  if (next === 'type') $('sourceText').focus();
}
function voiceError(shortMessage, details = shortMessage) {
  $('voiceHint').textContent = shortMessage;
  $('voiceStage').classList.add('has-error');
  sayToast(details);
}

async function translate(text) {
  if (!text.trim()) { showTranslation(''); return; }
  const from = sourceLang.value, to = targetLang.value;
  const translationInput = $('dialectMode').checked && from === 'ml' ? normalizeMalappuram(text) : text;
  if (to === 'manglish') {
    if (from === 'ml') showTranslation(malayalamRomanize(translationInput), to);
    else if (from === 'en') showTranslation(text, to);
    else showTranslation(await requestTranslation(text, from, 'ml').then(malayalamRomanize), to);
    return;
  }
  if (from === to) { showTranslation(translationInput, to); return; }
  const result = await requestTranslation(translationInput, from, to);
  if (result) showTranslation(result, to);
}
async function requestTranslation(text, from, to) {
  // MyMemory is a public translation endpoint; keep requests short and show a useful state on failure.
  const query = text.slice(0, 450);
  try {
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(query)}&langpair=${encodeURIComponent(`${from}|${to}`)}`;
    const response = await fetch(url);
    if (!response.ok) throw new Error('Translation service unavailable');
    const data = await response.json();
    const result = data?.responseData?.translatedText;
    if (!result || data.responseStatus >= 400) throw new Error(data?.responseDetails || 'No translation returned');
    $('translationNote').textContent = text.length > 450 ? 'First 450 characters translated · Check important text before sharing' : 'Translations powered by the web · Check important text before sharing';
    return decodeEntities(result);
  } catch (error) {
    $('translationNote').textContent = 'Could not reach the translation service · Check your connection and try again';
    showTranslation('Translation is unavailable right now. Please try again.', to);
    return '';
  }
}
function queueTranslation() {
  clearTimeout(translateTimer);
  const input = getInput();
  if (!input) { showTranslation(''); return; }
  showTranslation('Translating…');
  translateTimer = setTimeout(async () => {
    const snapshot = getInput(); translating = true;
    await translate(snapshot);
    translating = false;
    if (getInput() !== snapshot) queueTranslation();
  }, 450);
}
function decodeEntities(value) { const el = document.createElement('textarea'); el.innerHTML = value; return el.value; }

// Normalize a small, documented starter vocabulary while leaving the user's original text untouched.
function normalizeMalappuram(text) {
  const entries = [
    [/\bante\s+perenth\b/gi, 'അവന്റെ പേരെന്താണ്'],
    [/\bjja?\s+manisanakan\s+nokku\b/gi, 'നീ മനുഷ്യനാകാൻ നോക്ക്'],
    [/\bonte\s+thoudaram\b/gi, 'അവന്റെ സംസാരം'],
    [/\bmuseebathinte\s+edangeru\b/gi, 'കഷ്ടപ്പാടിന്റെ അങ്ങേയറ്റം'],
    [/\bnjammale\s+changayi\b/gi, 'നമ്മുടെ സുഹൃത്ത്'],
    [/അന്റെ\s*പെരെന്ത്/gi, 'അവന്റെ പേരെന്താണ്'],
    [/ജ്ജ്\s*മനിസനാകാൻ\s*നോക്ക്/gi, 'നീ മനുഷ്യനാകാൻ നോക്ക്'],
    [/ഓന്റെ\s*തൗദാരം/gi, 'അവന്റെ സംസാരം'],
    [/മുസീബത്തിന്റെ\s*എടങ്ങേറ്/gi, 'കഷ്ടപ്പാടിന്റെ അങ്ങേയറ്റം'],
    [/ഞമ്മളെ\s*ചങ്ങായി/gi, 'നമ്മുടെ സുഹൃത്ത്']
  ];
  return entries.reduce((result, [pattern, replacement]) => result.replace(pattern, replacement), text);
}

// A lightweight Malayalam-to-Latin approximation for the Manglish display mode.
function malayalamRomanize(input) {
  const letters = { 'അ':'a','ആ':'aa','ഇ':'i','ഈ':'ee','ഉ':'u','ഊ':'oo','ഋ':'ri','എ':'e','ഏ':'e','ഐ':'ai','ഒ':'o','ഓ':'o','ഔ':'au','ക':'k','ഖ':'kh','ഗ':'g','ഘ':'gh','ങ':'ng','ച':'ch','ഛ':'chh','ജ':'j','ഝ':'jh','ഞ':'nj','ട':'t','ഠ':'th','ഡ':'d','ഢ':'dh','ണ':'n','ത':'th','ഥ':'th','ദ':'d','ധ':'dh','ന':'n','പ':'p','ഫ':'ph','ബ':'b','ഭ':'bh','മ':'m','യ':'y','ര':'r','ല':'l','വ':'v','ശ':'sh','ഷ':'sh','സ':'s','ഹ':'h','ള':'l','ഴ':'zh','റ':'r','ൻ':'n','ൺ':'n','ർ':'r','ൽ':'l','ൾ':'l','്':'' };
  const signs = { 'ാ':'aa','ി':'i','ീ':'ee','ു':'u','ൂ':'oo','ൃ':'ri','െ':'e','േ':'e','ൈ':'ai','ൊ':'o','ോ':'o','ൗ':'au','ം':'m','ഃ':'h' };
  return [...input].map((char, i, chars) => {
    if (signs[char]) return signs[char];
    if (letters[char] !== undefined) {
      const next = chars[i + 1];
      if (letters[char] && next !== '്' && !signs[next] && char !== 'അ' && /[ക-ഹളഴറ]/.test(char)) return letters[char] + 'a';
      return letters[char];
    }
    return char;
  }).join('').replace(/aa(a)+/g, 'aa');
}

document.querySelectorAll('.mode-tab').forEach((tab) => tab.addEventListener('click', () => setMode(tab.dataset.mode)));
$('sourceText').addEventListener('input', (event) => setInput(event.target.value));
originalText.addEventListener('input', () => { updateCounts(); $('sourceText').value = originalText.value; queueTranslation(); });
sourceLang.addEventListener('change', queueTranslation);
targetLang.addEventListener('change', () => { labelTarget(); queueTranslation(); });
$('dialectMode').addEventListener('change', queueTranslation);
$('swapLanguages').addEventListener('click', () => {
  if (targetLang.value === 'manglish') targetLang.value = 'ml';
  const previous = sourceLang.value; sourceLang.value = targetLang.value; targetLang.value = previous; labelTarget(); queueTranslation();
});
$('clearInput').addEventListener('click', () => { setInput(''); $('sourceText').focus(); });

function setupRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) return null;
  const instance = new SpeechRecognition(); instance.continuous = true; instance.interimResults = true; instance.maxAlternatives = 1;
  instance.onstart = () => { listening = true; $('micButton').classList.add('recording'); $('voiceStage').classList.add('is-recording'); $('voiceStage').classList.remove('has-error'); $('voiceHint').textContent = 'Listening… speak naturally'; $('micButton').setAttribute('aria-label', 'Stop speaking'); };
  instance.onresult = (event) => {
    let interim = '', final = '';
    for (let i = 0; i < event.results.length; i++) { const result = event.results[i]; if (result.isFinal) final += result[0].transcript; else interim += result[0].transcript; }
    const value = [final, interim].filter(Boolean).join(' ').trim(); setInput(value);
  };
  instance.onerror = (event) => {
    const messages = {
      'not-allowed': 'Mic permission is blocked. Allow it in browser site settings, then try again.',
      'service-not-allowed': 'This browser or page cannot use its speech service. Try Chrome or Edge on HTTPS.',
      'network': 'The browser speech service could not connect. Check internet, VPN or firewall settings, then tap the mic again. If this preview still fails, try Chrome on localhost or HTTPS.',
      'no-speech': 'No speech was detected. Tap the mic and speak a little closer.',
      'audio-capture': 'No microphone was found. Connect or enable a microphone, then try again.'
    };
    if (event.error !== 'aborted') { const message = messages[event.error] || `Voice recognition error: ${event.error}.`; voiceError(event.error === 'network' ? 'Speech service unavailable. Try again or use Type mode.' : 'Voice could not start. Check Mic help for steps.', message); }
  };
  instance.onend = () => { listening = false; $('micButton').classList.remove('recording'); $('voiceStage').classList.remove('is-recording'); if ($('voiceHint').textContent === 'Listening… speak naturally') $('voiceHint').textContent = 'Tap the mic and start speaking'; $('micButton').setAttribute('aria-label', 'Start speaking'); };
  return instance;
}
async function startListening() {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) { voiceError('Voice recognition is not supported in this browser.', 'Live speech recognition is not supported in this browser. Try Chrome or Edge.'); return; }
  if (!navigator.mediaDevices?.getUserMedia) { voiceError('Open the app on localhost or HTTPS to use the mic.', 'Microphone access needs HTTPS or a supported secure browser page. Open the app on localhost or HTTPS.'); return; }
  $('voiceStage').classList.remove('has-error'); $('voiceHint').textContent = 'Checking microphone…';
  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((track) => track.stop());
  } catch (error) {
    const message = error.name === 'NotAllowedError'
      ? 'Mic permission is blocked. Allow it in the browser site settings, then tap the mic again.'
      : error.name === 'NotFoundError'
        ? 'No microphone was found. Connect or enable a microphone, then try again.'
        : 'Could not access the microphone. Check browser and device privacy settings.';
    voiceError(error.name === 'NotAllowedError' ? 'Microphone permission is blocked.' : 'Could not access the microphone.', message); return;
  }
  recognition = setupRecognition(); recognition.lang = sourceLang.value === 'manglish' ? 'ml-IN' : ({ ml:'ml-IN', en:'en-US', ta:'ta-IN', hi:'hi-IN', ar:'ar-SA' }[sourceLang.value] || 'ml-IN');
  try { recognition.start(); } catch { sayToast('Microphone is already starting.'); }
}
function stopListening() { try { recognition?.stop(); } catch {} listening = false; }
$('micButton').addEventListener('click', () => listening ? stopListening() : startListening());
document.addEventListener('keydown', (event) => {
  if (event.code === 'Space' && !event.repeat && !['TEXTAREA','INPUT','SELECT','BUTTON'].includes(document.activeElement.tagName) && !document.querySelector('#helpDialog[open]')) { event.preventDefault(); listening ? stopListening() : startListening(); }
});

function speak(text, lang) {
  if (!text.trim()) { sayToast('There is no text to read yet.'); return; }
  if (!('speechSynthesis' in window)) { sayToast('Text-to-speech is not available in this browser.'); return; }
  window.speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = ({ ml:'ml-IN', en:'en-US', ta:'ta-IN', hi:'hi-IN', ar:'ar-SA', manglish:'en-IN' }[lang] || 'en-US');
  utterance.onend = () => { if (window.speechSynthesis.paused) window.speechSynthesis.resume(); };
  window.speechSynthesis.speak(utterance);
}
$('listenTranslation').addEventListener('click', () => speak(translationText.textContent, targetLang.value));

async function copy(text, label) { if (!text.trim()) { sayToast('Nothing to copy yet.'); return; } try { await navigator.clipboard.writeText(text); sayToast(`${label} copied`); } catch { sayToast('Clipboard access is unavailable in this browser.'); } }
$('copyTranslation').addEventListener('click', () => copy(translationText.textContent, 'Translation'));
$('copyBoth').addEventListener('click', () => copy(`Original:\n${getInput()}\n\nTranslation:\n${translationText.textContent}`, 'Both texts'));
$('shareButton').addEventListener('click', async () => {
  const text = translationText.textContent.trim(); if (!text) return sayToast('There is no translation to share yet.');
  if (navigator.share) { try { await navigator.share({ title: 'salih.ai translation', text }); } catch (error) { if (error.name !== 'AbortError') sayToast('Sharing is unavailable.'); } }
  else copy(text, 'Translation');
});

function selectImage(file) {
  if (!file || !file.type.startsWith('image/')) return sayToast('Choose an image file to scan.');
  currentImage = file; $('previewImg').src = URL.createObjectURL(file); $('fileName').textContent = file.name || 'Pasted image'; $('fileSize').textContent = `${Math.max(1, Math.round(file.size / 1024))} KB`;
  $('imageEmpty').classList.add('hidden'); $('imagePreview').classList.remove('hidden'); $('scanButton').disabled = false;
}
$('uploadButton').addEventListener('click', () => $('imageFile').click());
$('cameraButton').addEventListener('click', () => $('cameraFile').click());
for (const id of ['imageFile','cameraFile']) $(id).addEventListener('change', (event) => selectImage(event.target.files[0]));
$('removeImage').addEventListener('click', () => { currentImage = null; $('previewImg').removeAttribute('src'); $('imagePreview').classList.add('hidden'); $('imageEmpty').classList.remove('hidden'); $('scanButton').disabled = true; });
const dropZone = $('dropZone');
dropZone.addEventListener('dragover', (event) => { event.preventDefault(); dropZone.classList.add('dragover'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
dropZone.addEventListener('drop', (event) => { event.preventDefault(); dropZone.classList.remove('dragover'); selectImage(event.dataTransfer.files[0]); });
document.addEventListener('paste', (event) => { const item = [...(event.clipboardData?.items || [])].find((entry) => entry.type.startsWith('image/')); if (item) { const file = item.getAsFile(); if (file) selectImage(file); } });

async function loadTesseract() {
  if (window.Tesseract) return window.Tesseract;
  if (!tesseractPromise) tesseractPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script'); script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js'; script.onload = () => resolve(window.Tesseract); script.onerror = () => reject(new Error('Could not load the OCR engine.'));
    document.head.append(script);
  });
  return tesseractPromise;
}
$('scanButton').addEventListener('click', async () => {
  if (!currentImage) return;
  $('scanButton').disabled = true; $('progressWrap').classList.remove('hidden'); $('progressBar').style.width = '0%'; $('progressPct').textContent = '0%'; $('progressText').textContent = 'Preparing scanner…';
  try {
    const Tesseract = await loadTesseract();
    const worker = await Tesseract.createWorker($('ocrLang').value, 1, { logger: (message) => {
      if (message.status) $('progressText').textContent = message.status === 'recognizing text' ? 'Reading text from image…' : message.status;
      const percent = Math.round((message.progress || 0) * 100); $('progressBar').style.width = `${percent}%`; $('progressPct').textContent = `${percent}%`;
    } });
    const result = await worker.recognize(currentImage); await worker.terminate();
    setInput(result.data.text || 'No text found in this image.'); sayToast('Image text extracted');
  } catch (error) { sayToast(error.message || 'Could not read this image.'); }
  finally { $('scanButton').disabled = !currentImage; setTimeout(() => $('progressWrap').classList.add('hidden'), 1200); }
});

$('micHelp').addEventListener('click', () => $('helpDialog').showModal());
$('testMic').addEventListener('click', async () => {
  $('micTestResult').textContent = 'Checking microphone access…';
  if (!navigator.mediaDevices?.getUserMedia) { $('micTestResult').textContent = 'Microphone checks require a secure page (HTTPS) and a supported browser.'; return; }
  try { const stream = await navigator.mediaDevices.getUserMedia({ audio: true }); stream.getTracks().forEach((track) => track.stop()); $('micTestResult').textContent = 'Microphone access is working. Try Voice mode again.'; }
  catch (error) { $('micTestResult').textContent = error.name === 'NotAllowedError' ? 'Access was denied. Allow microphone access in browser settings, then retry.' : 'No microphone was found. Check that one is connected and enabled.'; }
});
labelTarget(); updateCounts();
